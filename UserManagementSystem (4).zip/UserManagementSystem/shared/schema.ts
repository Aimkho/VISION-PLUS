import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  address: text("address"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastVisit: timestamp("last_visit"),
  notes: text("notes"),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  userId: integer("user_id").notNull(),
  amount: decimal("amount").notNull(),
  type: text("type").notNull(), // payment, refund
  paymentMethod: text("payment_method").notNull(), // cash, card, etc.
  status: text("status").notNull(), // pending, completed, cancelled
  reference: text("reference").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  notes: text("notes"),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull(), // admin or employee
  email: text("email").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  accessCode: text("access_code").notNull().unique(),
  permissions: text("permissions").notNull().default('[]'), // JSON array of permissions
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  assignedTo: integer("assigned_to").notNull(), // ID de l'utilisateur
  status: text("status").notNull(), // pending, in_progress, completed
  priority: text("priority").notNull(), // low, medium, high
  createdAt: timestamp("created_at").notNull().defaultNow(),
  dueDate: timestamp("due_date"),
});

export const accountingTemplates = pgTable("accounting_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // regular, provision, closing
  entries: text("entries").notNull(), // JSON array of entry templates
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const accountingEntries = pgTable("accounting_entries", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  description: text("description").notNull(),
  reference: text("reference").notNull(),
  accountNumber: text("account_number").notNull(),
  debit: decimal("debit").notNull().default("0"),
  credit: decimal("credit").notNull().default("0"),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // regular, provision, closing, opening_balance
  status: text("status").notNull(), // draft, posted
  period: text("period").notNull(), // YYYY-MM format
  tags: text("tags"), // JSON array of search tags
  metadata: text("metadata"), // JSON object for additional data
});

export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  accountNumber: text("account_number").notNull().unique(),
  accountName: text("account_name").notNull(),
  accountType: text("account_type").notNull(), // asset, liability, equity, revenue, expense
  category: text("category").notNull(), // operational, financial, etc.
  balance: decimal("balance").notNull().default("0"),
  openingBalance: decimal("opening_balance").notNull().default("0"),
  isActive: boolean("is_active").notNull().default(true),
});

export const accountingRules = pgTable("accounting_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // validation, automation
  conditions: text("conditions").notNull(), // JSON object of rule conditions
  actions: text("actions").notNull(), // JSON object of rule actions
  isActive: boolean("is_active").notNull().default(true),
});

export const financialActivities = pgTable("financial_activities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  accountMapping: text("account_mapping").notNull(), // JSON object mapping activities to accounts
  isActive: boolean("is_active").notNull().default(true),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // task, accounting, system
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const collectionSheets = pgTable("collection_sheets", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  collectedBy: integer("collected_by").notNull(),
  totalAmount: decimal("total_amount").notNull().default("0"),
  status: text("status").notNull(), // draft, validated
  notes: text("notes"),
});

// Schemas for insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
  email: true,
  accessCode: true,
  permissions:true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  description: true,
  assignedTo: true,
  status: true,
  priority: true,
  dueDate: true,
});

export const insertAccountingTemplateSchema = createInsertSchema(accountingTemplates).pick({
  name: true,
  description: true,
  type: true,
  entries: true,
  createdBy: true,
});

export const insertAccountingEntrySchema = createInsertSchema(accountingEntries).pick({
  date: true,
  description: true,
  reference: true,
  accountNumber: true,
  debit: true,
  credit: true,
  userId: true,
  type: true,
  status: true,
  period: true,
  tags: true,
  metadata: true,
});

export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).pick({
  accountNumber: true,
  accountName: true,
  accountType: true,
  category: true,
  openingBalance: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  userId: true,
  title: true,
  message: true,
  type: true,
});

export const insertCollectionSheetSchema = createInsertSchema(collectionSheets).pick({
  date: true,
  collectedBy: true,
  totalAmount: true,
  status: true,
  notes: true,
});

export const insertAccountingRuleSchema = createInsertSchema(accountingRules).pick({
  name: true,
  description: true,
  type: true,
  conditions: true,
  actions: true,
});

export const insertFinancialActivitySchema = createInsertSchema(financialActivities).pick({
  name: true,
  description: true,
  accountMapping: true,
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  fullName: true,
  email: true,
  phone: true,
  address: true,
  notes: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  customerId: true,
  userId: true,
  amount: true,
  type: true,
  paymentMethod: true,
  status: true,
  reference: true,
  notes: true,
});


// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type AccountingEntry = typeof accountingEntries.$inferSelect;
export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type CollectionSheet = typeof collectionSheets.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertAccountingEntry = z.infer<typeof insertAccountingEntrySchema>;
export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type InsertCollectionSheet = z.infer<typeof insertCollectionSheetSchema>;
export type AccountingTemplate = typeof accountingTemplates.$inferSelect;
export type InsertAccountingTemplate = z.infer<typeof insertAccountingTemplateSchema>;
export type AccountingRule = typeof accountingRules.$inferSelect;
export type InsertAccountingRule = z.infer<typeof insertAccountingRuleSchema>;
export type FinancialActivity = typeof financialActivities.$inferSelect;
export type InsertFinancialActivity = z.infer<typeof insertFinancialActivitySchema>;
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;