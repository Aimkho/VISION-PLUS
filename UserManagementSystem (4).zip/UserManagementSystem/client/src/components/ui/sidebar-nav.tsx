import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import {
  LayoutDashboard,
  FileText,
  BookOpen,
  Inbox,
  ClipboardList,
  Users,
  Bell,
  LogOut,
  Settings,
  CreditCard,
  BookmarkCheck,
  Activity,
  GitBranch,
  Shield,
  Key,
  ShoppingCart,
  UserSquare,
} from "lucide-react";

export function SidebarNav() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const navigation = [
    { name: 'Tableau de bord', href: '/', icon: LayoutDashboard },
    { name: 'Boîte de réception', href: '/inbox', icon: Inbox },
    { name: 'Tâches', href: '/tasks', icon: ClipboardList },
    {
      name: 'Comptabilité',
      items: [
        { name: 'Publications fréquentes', href: '/accounting/templates', icon: FileText },
        { name: 'Journal comptable', href: '/accounting/journal', icon: BookOpen },
        { name: 'Plan comptable', href: '/accounting/chart', icon: FileText },
        { name: 'Clôture', href: '/accounting/closing', icon: BookmarkCheck },
        { name: 'Activités financières', href: '/accounting/activities', icon: Activity },
        { name: 'Règles comptables', href: '/accounting/rules', icon: GitBranch },
        { name: 'Provisions', href: '/accounting/provisions', icon: Shield },
      ]
    },
    { name: 'Gestion Clientèle', href: '/customers', icon: UserSquare },
    { name: 'Caisse', href: '/cashier', icon: ShoppingCart },
    { name: 'Feuille de collecte', href: '/collection', icon: CreditCard },
    ...(user?.role === 'admin' ? [
      { name: 'Gestion du personnel', href: '/employees', icon: Users },
      { name: 'Codes d\'accès', href: '/access-codes', icon: Key }
    ] : []),
  ];

  return (
    <div className="flex flex-col w-64 bg-sidebar border-r">
      <div className="h-20 flex items-center px-4 border-b">
        <div className="flex items-center gap-3">
          <img src="/logo.svg" alt="Vision Plus" className="h-8 w-8" />
          <h1 className="text-xl font-bold text-sidebar-foreground">VISION PLUS</h1>
        </div>
      </div>

      <nav className="flex-1 px-2 py-4 space-y-1">
        {navigation.map((item) => {
          if (item.items) {
            return (
              <div key={item.name} className="space-y-1">
                <div className="px-3 py-2 text-sm font-medium text-sidebar-foreground/70">
                  {item.name}
                </div>
                {item.items.map((subItem) => {
                  const isActive = location === subItem.href;
                  return (
                    <Link key={subItem.name} href={subItem.href}>
                      <Button
                        variant={isActive ? "secondary" : "ghost"}
                        className={cn(
                          "w-full justify-start gap-2 pl-6",
                          isActive && "bg-sidebar-accent text-sidebar-accent-foreground"
                        )}
                      >
                        <subItem.icon className="h-4 w-4" />
                        {subItem.name}
                      </Button>
                    </Link>
                  );
                })}
              </div>
            );
          }

          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <Button
                variant={isActive ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start gap-2",
                  isActive && "bg-sidebar-accent text-sidebar-accent-foreground"
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.name}
              </Button>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t space-y-4">
        <div className="px-2 flex items-center gap-2">
          <div className="flex-1">
            <div className="text-sm font-medium">{user?.fullName}</div>
            <div className="text-xs text-sidebar-foreground/70">
              {user?.role === 'admin' ? 'Administrateur' : 'Employé'}
            </div>
          </div>
          <Button
            variant="outline"
            size="icon"
            className="relative"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />
          </Button>
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start gap-2"
          onClick={() => logoutMutation.mutate()}
        >
          <LogOut className="h-4 w-4" />
          Déconnexion
        </Button>
      </div>
    </div>
  );
}