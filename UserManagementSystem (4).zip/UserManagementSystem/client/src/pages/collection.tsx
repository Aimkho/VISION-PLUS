import { useQuery } from "@tanstack/react-query";
import { CollectionSheet } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, CreditCard } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function Collection() {
  const { data: sheets, isLoading } = useQuery<CollectionSheet[]>({
    queryKey: ["/api/collection-sheets"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Feuilles de Collecte</h1>
          <p className="text-muted-foreground mt-1">
            Gérez vos feuilles de collecte quotidiennes
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nouvelle Feuille
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Liste des Feuilles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Collecteur</TableHead>
                  <TableHead className="text-right">Montant Total</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sheets?.map((sheet) => (
                  <TableRow key={sheet.id}>
                    <TableCell>
                      {format(new Date(sheet.date), "d MMMM yyyy", { locale: fr })}
                    </TableCell>
                    <TableCell>{sheet.collectedBy}</TableCell>
                    <TableCell className="text-right font-mono">
                      {Number(sheet.totalAmount).toLocaleString('fr-FR', {
                        style: 'currency',
                        currency: 'EUR'
                      })}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={sheet.status === 'validated' ? 'default' : 'secondary'}
                      >
                        {sheet.status === 'validated' ? 'Validée' : 'Brouillon'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {sheet.notes || '-'}
                    </TableCell>
                  </TableRow>
                ))}

                {(!sheets || sheets.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center h-24 text-muted-foreground">
                      Aucune feuille de collecte
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
