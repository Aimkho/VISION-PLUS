import { useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, CheckCircle2, Circle, Clock } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useAuth } from "@/hooks/use-auth";

export default function Tasks() {
  const { user } = useAuth();
  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  const myTasks = tasks?.filter((task) => task.assignedTo === user?.id);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Mes Tâches</h1>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nouvelle Tâche
        </Button>
      </div>v>

      <div className="grid gap-4 md:grid-cols-3">
        <TaskColumn
          title="À faire"
          tasks={myTasks?.filter((t) => t.status === "pending")}
          icon={Circle}
        />
        <TaskColumn
          title="En cours"
          tasks={myTasks?.filter((t) => t.status === "in_progress")}
          icon={Clock}
        />
        <TaskColumn
          title="Terminé"
          tasks={myTasks?.filter((t) => t.status === "completed")}
          icon={CheckCircle2}
        />
      </div>
    </div>
  );
}

function TaskColumn({ title, tasks, icon: Icon }: { 
  title: string;
  tasks?: Task[];
  icon: typeof Circle;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Icon className="h-5 w-5" />
          {title}
          {tasks && <Badge variant="secondary">{tasks.length}</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {tasks?.map((task) => (
          <Card key={task.id}>
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="flex items-start justify-between">
                  <h3 className="font-medium">{task.title}</h3>
                  <Badge variant={
                    task.priority === "high" ? "destructive" :
                    task.priority === "medium" ? "default" :
                    "secondary"
                  }>
                    {task.priority === "high" ? "Urgent" :
                     task.priority === "medium" ? "Normal" :
                     "Faible"}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{task.description}</p>
                {task.dueDate && (
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Échéance : {format(new Date(task.dueDate), "d MMMM yyyy", { locale: fr })}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}

        {(!tasks || tasks.length === 0) && (
          <div className="text-center py-4 text-sm text-muted-foreground">
            Aucune tâche
          </div>
        )}
      </CardContent>
    </Card>
  );
}
