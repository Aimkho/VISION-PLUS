import { useQuery } from "@tanstack/react-query";
import { AccountingEntry } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, FileText } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function AccountingJournal() {
  const { data: entries, isLoading } = useQuery<AccountingEntry[]>({
    queryKey: ["/api/accounting/entries"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Journal Comptable</h1>
          <p className="text-muted-foreground mt-1">
            Consultez et ajoutez des écritures comptables
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nouvelle Écriture
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Écritures Comptables
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Réf.</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>N° Compte</TableHead>
                  <TableHead className="text-right">Débit</TableHead>
                  <TableHead className="text-right">Crédit</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Statut</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entries?.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell>
                      {format(new Date(entry.date), "dd/MM/yyyy", { locale: fr })}
                    </TableCell>
                    <TableCell>{entry.reference}</TableCell>
                    <TableCell>{entry.description}</TableCell>
                    <TableCell>{entry.accountNumber}</TableCell>
                    <TableCell className="text-right font-mono">
                      {Number(entry.debit).toLocaleString('fr-FR', {
                        style: 'currency',
                        currency: 'EUR'
                      })}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {Number(entry.credit).toLocaleString('fr-FR', {
                        style: 'currency',
                        currency: 'EUR'
                      })}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {entry.type === 'regular' ? 'Standard' : 'Clôture'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={entry.status === 'posted' ? 'default' : 'secondary'}
                      >
                        {entry.status === 'posted' ? 'Validée' : 'Brouillon'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}

                {(!entries || entries.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center h-24 text-muted-foreground">
                      Aucune écriture comptable
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
