import { useQuery } from "@tanstack/react-query";
import { AccountingEntry } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, BookmarkCheck } from "lucide-react";

export default function AccountingClosing() {
  const { data: closingEntries } = useQuery<AccountingEntry[]>({
    queryKey: ["/api/accounting/entries/closing"],
  });

  const hasClosingEntries = closingEntries && closingEntries.length > 0;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Clôture Comptable</h1>
          <p className="text-muted-foreground mt-1">
            Effectuez la clôture des comptes en fin d'exercice
          </p>
        </div>
        <Button variant="outline">
          <BookmarkCheck className="h-4 w-4 mr-2" />
          Clôturer l'exercice
        </Button>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Information</AlertTitle>
        <AlertDescription>
          La clôture des comptes est une opération irréversible qui doit être effectuée à la fin de chaque exercice comptable.
          Assurez-vous d'avoir saisi toutes les écritures de l'exercice avant de procéder à la clôture.
        </AlertDescription>
      </Alert>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Vérifications pré-clôture</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <CheckItem
                title="Balance des comptes"
                description="Vérifier que tous les comptes sont équilibrés"
                status="pending"
              />
            </div>
            <div className="flex items-center gap-2">
              <CheckItem
                title="Écritures en brouillon"
                description="Valider toutes les écritures en attente"
                status="warning"
              />
            </div>
            <div className="flex items-center gap-2">
              <CheckItem
                title="Rapprochement bancaire"
                description="Effectuer le rapprochement bancaire final"
                status="pending"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>État de la clôture</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center py-8">
              <BookmarkCheck className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
              <p className="text-lg font-medium mb-2">
                {hasClosingEntries
                  ? "Clôture en cours"
                  : "Exercice comptable ouvert"}
              </p>
              <p className="text-sm text-muted-foreground">
                {hasClosingEntries
                  ? "Des écritures de clôture ont été générées"
                  : "Aucune écriture de clôture n'a été générée"}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function CheckItem({ 
  title, 
  description, 
  status 
}: { 
  title: string;
  description: string;
  status: "success" | "warning" | "pending";
}) {
  return (
    <div className="border rounded-lg p-4 w-full">
      <div className="flex items-start gap-4">
        <div className={`rounded-full w-2 h-2 mt-2 ${
          status === "success" ? "bg-green-500" :
          status === "warning" ? "bg-yellow-500" :
          "bg-gray-300"
        }`} />
        <div>
          <h3 className="font-medium">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  );
}
