import { useQuery, useMutation } from "@tanstack/react-query";
import { AccountingEntry } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertAccountingEntrySchema } from "@shared/schema";
import { Loader2, Plus, Shield } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Provisions() {
  const { user } = useAuth();
  const { data: provisions, isLoading } = useQuery<AccountingEntry[]>({
    queryKey: ["/api/accounting/entries", { type: "provision" }],
  });

  const form = useForm({
    resolver: zodResolver(insertAccountingEntrySchema),
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      description: "",
      accountNumber: "",
      debit: "0",
      credit: "0",
      type: "provision",
      status: "draft",
      userId: user?.id,
    },
  });

  const createProvision = useMutation({
    mutationFn: async (data: AccountingEntry) => {
      const res = await apiRequest("POST", "/api/accounting/entries", {
        ...data,
        type: "provision",
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounting/entries"] });
      form.reset();
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Provisions</h1>
          <p className="text-muted-foreground mt-1">
            Gérez les écritures de provision
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-primary/90 to-primary">
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle Provision
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Créer une Provision</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={form.handleSubmit((data) => createProvision.mutate(data))}
              className="space-y-4"
            >
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input
                    type="date"
                    id="date"
                    {...form.register("date")}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accountNumber">N° Compte</Label>
                  <Input
                    id="accountNumber"
                    placeholder="Numéro de compte"
                    {...form.register("accountNumber")}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Description de la provision"
                  {...form.register("description")}
                />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="debit">Débit</Label>
                  <Input
                    type="number"
                    id="debit"
                    step="0.01"
                    {...form.register("debit")}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="credit">Crédit</Label>
                  <Input
                    type="number"
                    id="credit"
                    step="0.01"
                    {...form.register("credit")}
                  />
                </div>
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={createProvision.isPending}
              >
                {createProvision.isPending ? "Création..." : "Créer la provision"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Liste des Provisions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {provisions?.map((provision) => (
              <div
                key={provision.id}
                className="p-4 border rounded-lg flex items-center justify-between"
              >
                <div>
                  <p className="font-medium">{provision.description}</p>
                  <p className="text-sm text-muted-foreground">
                    Compte: {provision.accountNumber}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-mono">
                    {Number(provision.debit).toLocaleString('fr-FR', {
                      style: 'currency',
                      currency: 'EUR'
                    })}
                  </p>
                  <Button variant="outline" size="sm" className="mt-2">
                    Modifier
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
