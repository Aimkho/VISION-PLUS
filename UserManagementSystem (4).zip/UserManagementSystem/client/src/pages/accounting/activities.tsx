import { useQuery, useMutation } from "@tanstack/react-query";
import { FinancialActivity } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFinancialActivitySchema } from "@shared/schema";
import { Loader2, Plus, Activity } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function FinancialActivities() {
  const { data: activities, isLoading } = useQuery<FinancialActivity[]>({
    queryKey: ["/api/accounting/activities"],
  });

  const form = useForm({
    resolver: zodResolver(insertFinancialActivitySchema),
    defaultValues: {
      name: "",
      description: "",
      accountMapping: "{}",
    },
  });

  const createActivity = useMutation({
    mutationFn: async (data: FinancialActivity) => {
      const res = await apiRequest("POST", "/api/accounting/activities", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounting/activities"] });
      form.reset();
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Activités Financières</h1>
          <p className="text-muted-foreground mt-1">
            Gérez les correspondances entre activités et comptes
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-primary/90 to-primary">
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle Activité
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Créer une Activité Financière</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={form.handleSubmit((data) => createActivity.mutate(data))}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label htmlFor="name">Nom de l'activité</Label>
                <Input
                  id="name"
                  placeholder="Nom de l'activité"
                  {...form.register("name")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Description de l'activité"
                  {...form.register("description")}
                />
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={createActivity.isPending}
              >
                {createActivity.isPending ? "Création..." : "Créer l'activité"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {activities?.map((activity) => (
          <Card key={activity.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                {activity.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {activity.description}
              </p>
              <div className="flex justify-end">
                <Button variant="outline" size="sm">
                  Configurer les comptes
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
