import { useQuery, useMutation } from "@tanstack/react-query";
import { AccountingTemplate } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertAccountingTemplateSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Loader2, FileText } from "lucide-react";

export default function AccountingTemplates() {
  const { user } = useAuth();
  const { data: templates, isLoading } = useQuery<AccountingTemplate[]>({
    queryKey: ["/api/accounting/templates"],
  });

  const form = useForm({
    resolver: zodResolver(insertAccountingTemplateSchema),
    defaultValues: {
      name: "",
      description: "",
      type: "regular",
      entries: "[]",
      createdBy: user?.id,
    },
  });

  const createTemplate = useMutation({
    mutationFn: async (data: AccountingTemplate) => {
      const res = await apiRequest("POST", "/api/accounting/templates", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounting/templates"] });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Publications Fréquentes</h1>
          <p className="text-muted-foreground mt-1">
            Gérez vos modèles d'écritures comptables prédéfinis
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nouveau Modèle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Créer un Nouveau Modèle</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={form.handleSubmit((data) => createTemplate.mutate(data))}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label htmlFor="name">Nom du modèle</Label>
                <Input
                  id="name"
                  placeholder="Nom du modèle"
                  {...form.register("name")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Description du modèle"
                  {...form.register("description")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select
                  onValueChange={(value) => form.setValue("type", value)}
                  defaultValue={form.getValues("type")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez le type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="regular">Standard</SelectItem>
                    <SelectItem value="provision">Provision</SelectItem>
                    <SelectItem value="closing">Clôture</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={createTemplate.isPending}
              >
                {createTemplate.isPending ? "Création..." : "Créer le modèle"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {templates?.map((template) => (
          <Card key={template.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {template.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {template.description}
              </p>
              <div className="flex items-center justify-between">
                <Badge variant="outline">
                  {template.type === 'regular' && 'Standard'}
                  {template.type === 'provision' && 'Provision'}
                  {template.type === 'closing' && 'Clôture'}
                </Badge>
                <Button variant="outline" size="sm">
                  Utiliser
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
