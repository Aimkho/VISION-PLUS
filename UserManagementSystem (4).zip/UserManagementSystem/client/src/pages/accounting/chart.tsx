import { useQuery } from "@tanstack/react-query";
import { ChartOfAccount } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, BookOpen } from "lucide-react";

export default function AccountingChart() {
  const { data: accounts, isLoading } = useQuery<ChartOfAccount[]>({
    queryKey: ["/api/accounting/accounts"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Plan Comptable</h1>
          <p className="text-muted-foreground mt-1">
            Gérez votre plan comptable et visualisez les soldes
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nouveau Compte
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Liste des Comptes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>N° Compte</TableHead>
                  <TableHead>Intitulé</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Solde</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts?.map((account) => (
                  <TableRow key={account.id}>
                    <TableCell className="font-mono">{account.accountNumber}</TableCell>
                    <TableCell>{account.accountName}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {account.accountType === 'asset' && 'Actif'}
                        {account.accountType === 'liability' && 'Passif'}
                        {account.accountType === 'equity' && 'Capitaux Propres'}
                        {account.accountType === 'revenue' && 'Produit'}
                        {account.accountType === 'expense' && 'Charge'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {Number(account.balance).toLocaleString('fr-FR', {
                        style: 'currency',
                        currency: 'EUR'
                      })}
                    </TableCell>
                  </TableRow>
                ))}

                {(!accounts || accounts.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center h-24 text-muted-foreground">
                      Aucun compte comptable
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
