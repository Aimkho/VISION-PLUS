import { useQuery } from "@tanstack/react-query";
import { Notification } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bell, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useAuth } from "@/hooks/use-auth";

export default function Inbox() {
  const { user } = useAuth();
  const { data: notifications, isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  const unreadCount = notifications?.filter(n => !n.isRead).length;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Boîte de réception</h1>
        {unreadCount > 0 && (
          <Badge variant="secondary" className="text-base">
            {unreadCount} non lu{unreadCount > 1 ? 's' : ''}
          </Badge>
        )}
      </div>

      <div className="space-y-4">
        {notifications?.map((notification) => (
          <Card key={notification.id} className={!notification.isRead ? "bg-accent/5" : undefined}>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-base flex items-center gap-2">
                    {!notification.isRead && <Bell className="h-4 w-4 text-primary" />}
                    {notification.title}
                  </CardTitle>
                  <div className="text-sm text-muted-foreground">
                    {format(new Date(notification.createdAt), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
                  </div>
                </div>
                <Badge variant="outline">
                  {notification.type === 'task' && 'Tâche'}
                  {notification.type === 'accounting' && 'Comptabilité'}
                  {notification.type === 'system' && 'Système'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{notification.message}</p>
            </CardContent>
          </Card>
        ))}

        {notifications?.length === 0 && (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Aucune notification</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
