import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Key } from "lucide-react";
import { useLocation } from "wouter";

export default function ChangeAccessCode() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [currentCode, setCurrentCode] = useState("");
  const [newCode, setNewCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newCode !== confirmCode) {
      toast({
        title: "Erreur",
        description: "Les nouveaux codes ne correspondent pas",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await apiRequest("POST", "/api/change-access-code", {
        currentCode,
        newCode,
      });
      toast({
        title: "Succès",
        description: "Votre code d'accès a été modifié avec succès",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de modifier le code d'accès",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-full max-w-md p-6 space-y-6">
        <div className="flex items-center gap-2 mb-6">
          <Key className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Modifier votre code d'accès</h1>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="currentCode">Code d'accès actuel</Label>
            <Input
              id="currentCode"
              value={currentCode}
              onChange={(e) => setCurrentCode(e.target.value)}
              placeholder="Entrez votre code actuel"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="newCode">Nouveau code d'accès</Label>
            <Input
              id="newCode"
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
              placeholder="Entrez votre nouveau code"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirmCode">Confirmer le nouveau code</Label>
            <Input
              id="confirmCode"
              value={confirmCode}
              onChange={(e) => setConfirmCode(e.target.value)}
              placeholder="Confirmez votre nouveau code"
              required
            />
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? "Modification en cours..." : "Modifier le code d'accès"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
