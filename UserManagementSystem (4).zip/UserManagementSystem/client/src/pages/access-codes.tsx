import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Key, Copy, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";

export default function AccessCodes() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: employees, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  if (user?.role !== "admin") {
    return <Redirect to="/" />;
  }

  const copyAccessCode = (accessCode: string) => {
    navigator.clipboard.writeText(accessCode);
    toast({
      title: "Code d'accès copié",
      description: "Le code d'accès a été copié dans le presse-papier.",
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Codes d'Accès</h1>
          <p className="text-muted-foreground mt-1">
            Gérez les codes d'accès du personnel
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Liste des Codes d'Accès
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employé</TableHead>
                <TableHead>Code d'accès</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees?.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{employee.fullName}</div>
                      <div className="text-sm text-muted-foreground">
                        {employee.email}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="bg-muted px-3 py-1 rounded text-lg tracking-wider">
                      {employee.accessCode}
                    </code>
                  </TableCell>
                  <TableCell>
                    <Badge variant={employee.isActive ? "default" : "secondary"}>
                      {employee.isActive ? "Actif" : "Inactif"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyAccessCode(employee.accessCode)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Pour les administrateurs :</h3>
            <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
              <li>Les codes d'accès sont générés automatiquement à la création d'un employé</li>
              <li>Utilisez le bouton de copie pour partager le code avec l'employé</li>
              <li>Les codes sont en majuscules et contiennent 8 caractères</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium mb-2">Pour les employés :</h3>
            <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
              <li>Utilisez votre code d'accès pour vous connecter la première fois</li>
              <li>Le mot de passe initial est basé sur votre code d'accès</li>
              <li>Changez votre mot de passe après la première connexion</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
