import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, type InsertUser } from "@shared/schema";
import { Redirect } from "wouter";
import { Eye, Glasses } from "lucide-react";

type LoginData = Pick<InsertUser, "username" | "password">;

export default function AuthPage() {
  const { user, loginMutation } = useAuth();

  const loginForm = useForm<LoginData>({
    defaultValues: {
      username: "",
      password: "",
    },
  });

  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="flex min-h-screen">
      <div className="flex-1 p-8 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <form
              onSubmit={loginForm.handleSubmit((data) => loginMutation.mutate(data))}
              className="space-y-6"
            >
              <div className="space-y-2">
                <Label htmlFor="username">Code d'accès</Label>
                <Input
                  id="username"
                  placeholder="Entrez votre code d'accès"
                  className="text-center uppercase tracking-widest"
                  maxLength={8}
                  {...loginForm.register("username")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe</Label>
                <Input
                  type="password"
                  id="password"
                  placeholder="Entrez votre mot de passe"
                  {...loginForm.register("password")}
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary/90 to-primary"
                size="lg"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  "Connexion en cours..."
                ) : (
                  "Se connecter"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="hidden lg:flex flex-1 bg-sidebar items-center justify-center p-8">
        <div className="max-w-md text-sidebar-foreground">
          <div className="flex items-center gap-2 mb-8">
            <Glasses className="h-12 w-12" />
            <h1 className="text-4xl font-bold">Gestionnaire Optique</h1>
          </div>
          <p className="text-xl mb-8">
            Votre solution complète pour la gestion de votre entreprise d'optique.
          </p>
          <div className="space-y-6 text-lg">
            <Feature icon={Eye} text="Gestion financière avancée avec plan comptable" />
            <Feature icon={Eye} text="Suivi des tâches et notifications en temps réel" />
            <Feature icon={Eye} text="Tableaux de bord et rapports détaillés" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Feature({ icon: Icon, text }: { icon: typeof Eye; text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="p-2 rounded-lg bg-sidebar-accent/10">
        <Icon className="h-6 w-6" />
      </div>
      <span className="font-medium">{text}</span>
    </div>
  );
}