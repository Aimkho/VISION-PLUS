import { useQuery, useMutation } from "@tanstack/react-query";
import { User, insertUserSchema } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Redirect } from "wouter";
import { Loader2, Mail, UserPlus, Key, Copy } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const availablePermissions = [
  { id: "inbox", label: "Boîte de réception" },
  { id: "tasks", label: "Tâches" },
  { id: "accounting_journal", label: "Journal comptable" },
  { id: "accounting_chart", label: "Plan comptable" },
  { id: "accounting_closing", label: "Clôture comptable" },
  { id: "collection", label: "Feuille de collecte" },
  { id: "accounting_templates", label: "Publications fréquentes" },
  { id: "accounting_rules", label: "Règles comptables" },
  { id: "accounting_provisions", label: "Provisions" },
];

export default function Employees() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: employees, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const form = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      fullName: "",
      email: "",
      role: "employee",
      permissions: "[]",
    },
  });

  const createEmployee = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/users", {
        ...data,
        permissions: JSON.stringify(data.permissions || []),
      });
      return res.json();
    },
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Employé créé",
        description: `L'employé a été créé avec succès. Son code d'accès est : ${response.accessCode}`,
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: "Impossible de créer l'employé. Veuillez réessayer.",
        variant: "destructive",
      });
    }
  });

  if (user?.role !== "admin") {
    return <Redirect to="/" />;
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  const copyAccessCode = (accessCode: string) => {
    navigator.clipboard.writeText(accessCode);
    toast({
      title: "Code d'accès copié",
      description: "Le code d'accès a été copié dans le presse-papier.",
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestion des Employés</h1>
          <p className="text-muted-foreground mt-1">
            Gérez les employés et leurs accès au système
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="h-4 w-4 mr-2" />
              Nouvel Employé
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Ajouter un Employé</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={form.handleSubmit((data) => createEmployee.mutate(data))}
              className="space-y-6"
            >
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Nom complet</Label>
                  <Input
                    id="fullName"
                    placeholder="Nom complet de l'employé"
                    {...form.register("fullName")}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    type="email"
                    id="email"
                    placeholder="Email de l'employé"
                    {...form.register("email")}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <Label>Permissions d'accès</Label>
                <div className="grid gap-3 md:grid-cols-2">
                  {availablePermissions.map((permission) => (
                    <div key={permission.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={permission.id}
                        onCheckedChange={(checked) => {
                          const currentPermissions = form.getValues("permissions") 
                            ? JSON.parse(form.getValues("permissions"))
                            : [];
                          if (checked) {
                            form.setValue("permissions", JSON.stringify([...currentPermissions, permission.id]));
                          } else {
                            form.setValue(
                              "permissions",
                              JSON.stringify(currentPermissions.filter((p: string) => p !== permission.id))
                            );
                          }
                        }}
                      />
                      <Label htmlFor={permission.id} className="font-normal">
                        {permission.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary/90 to-primary"
                size="lg"
                disabled={createEmployee.isPending}
              >
                {createEmployee.isPending ? "Création..." : "Créer l'employé"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nom Complet</TableHead>
              <TableHead>Code d'accès</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Rôle</TableHead>
              <TableHead>Permissions</TableHead>
              <TableHead>Statut</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {employees?.map((employee) => (
              <TableRow key={employee.id}>
                <TableCell className="font-medium">
                  {employee.fullName}
                  <div className="text-sm text-muted-foreground">
                    ID: {employee.id}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Key className="h-4 w-4" />
                    <code className="bg-muted px-2 py-1 rounded">
                      {employee.accessCode}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => copyAccessCode(employee.accessCode)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    {employee.email}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={employee.role === "admin" ? "default" : "secondary"}
                  >
                    {employee.role === "admin" ? "Administrateur" : "Employé"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {JSON.parse(employee.permissions || '[]').map((permission: string) => (
                      <Badge key={permission} variant="outline" className="text-xs">
                        {availablePermissions.find(p => p.id === permission)?.label || permission}
                      </Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={employee.isActive ? "bg-green-50" : "bg-red-50"}>
                    {employee.isActive ? "Actif" : "Inactif"}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}