import { useQuery, useMutation } from "@tanstack/react-query";
import { Transaction, Customer, insertTransactionSchema } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Plus, CreditCard, Receipt } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatAmount } from "@/lib/utils";

export default function Cashier() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const { data: customers, isLoading: isLoadingCustomers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const form = useForm({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      customerId: undefined,
      amount: "",
      type: "payment",
      paymentMethod: "cash",
      status: "completed",
      notes: "",
      userId: user?.id,
    },
  });

  const createTransaction = useMutation({
    mutationFn: async (data: Transaction) => {
      const res = await apiRequest("POST", "/api/transactions", {
        ...data,
        reference: `TXN-${Date.now()}`,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Transaction créée",
        description: "La transaction a été enregistrée avec succès",
      });
      form.reset();
    },
  });

  if (isLoadingTransactions || isLoadingCustomers) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Caisse</h1>
          <p className="text-muted-foreground mt-1">
            Gérez les transactions et les paiements
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-primary/90 to-primary">
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle Transaction
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nouvelle Transaction</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={form.handleSubmit((data) => createTransaction.mutate(data))}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label htmlFor="customerId">Client</Label>
                <Select
                  onValueChange={(value) => form.setValue("customerId", Number(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez un client" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers?.map((customer) => (
                      <SelectItem key={customer.id} value={String(customer.id)}>
                        {customer.fullName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Montant</Label>
                <Input
                  type="number"
                  step="0.01"
                  id="amount"
                  placeholder="Montant"
                  {...form.register("amount")}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Mode de paiement</Label>
                <Select
                  onValueChange={(value) => form.setValue("paymentMethod", value)}
                  defaultValue="cash"
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Espèces</SelectItem>
                    <SelectItem value="card">Carte bancaire</SelectItem>
                    <SelectItem value="transfer">Virement</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Input
                  id="notes"
                  placeholder="Notes sur la transaction"
                  {...form.register("notes")}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={createTransaction.isPending}
              >
                {createTransaction.isPending ? "Traitement..." : "Enregistrer la transaction"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Transactions Récentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactions?.slice(0, 5).map((transaction) => {
                const customer = customers?.find(c => c.id === transaction.customerId);
                return (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div>
                      <p className="font-medium">{customer?.fullName}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(transaction.createdAt), "d MMMM yyyy", {
                          locale: fr,
                        })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-medium">
                        {formatAmount(transaction.amount)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {transaction.paymentMethod === "cash"
                          ? "Espèces"
                          : transaction.paymentMethod === "card"
                          ? "Carte bancaire"
                          : "Virement"}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5" />
              Résumé du Jour
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <p className="font-medium">Total des transactions</p>
                <p className="font-mono font-medium">
                  {formatAmount(
                    transactions
                      ?.filter(
                        (t) =>
                          new Date(t.createdAt).toDateString() ===
                          new Date().toDateString()
                      )
                      .reduce((sum, t) => sum + Number(t.amount), 0) || 0
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
