import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAmount(amount: string | number): string {
  const value = typeof amount === "string" ? parseFloat(amount) : amount;
  return value.toLocaleString('fr-FR', {
    style: 'currency',
    currency: 'EUR'
  });
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export function formatISODate(date: Date): string {
  return date.toISOString().split('T')[0];
}