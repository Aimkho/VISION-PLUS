import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";
import { SidebarNav } from "@/components/ui/sidebar-nav";
import { useToast } from "@/hooks/use-toast";

// Map routes to required permissions
const routePermissions: Record<string, string> = {
  '/inbox': 'inbox',
  '/tasks': 'tasks',
  '/accounting/journal': 'accounting_journal',
  '/accounting/chart': 'accounting_chart',
  '/accounting/closing': 'accounting_closing',
  '/accounting/templates': 'accounting_templates',
  '/accounting/rules': 'accounting_rules',
  '/accounting/provisions': 'accounting_provisions',
  '/collection': 'collection',
};

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-border" />
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  // Rediriger vers la page de changement de code d'accès si c'est la première connexion
  // et que nous ne sommes pas déjà sur cette page
  if (user.username === user.accessCode && path !== '/change-access-code') {
    return (
      <Route path={path}>
        <Redirect to="/change-access-code" />
      </Route>
    );
  }

  // Administrateurs ont accès à tout
  if (user.role !== 'admin') {
    const requiredPermission = routePermissions[path];
    if (requiredPermission) {
      const userPermissions = JSON.parse(user.permissions || '[]');
      if (!userPermissions.includes(requiredPermission)) {
        toast({
          title: "Accès refusé",
          description: "Vous n'avez pas la permission d'accéder à cette page.",
          variant: "destructive",
        });
        return (
          <Route path={path}>
            <Redirect to="/" />
          </Route>
        );
      }
    }
  }

  return (
    <Route path={path}>
      <div className="flex min-h-screen">
        <SidebarNav />
        <main className="flex-1 p-8">
          <Component />
        </main>
      </div>
    </Route>
  );
}