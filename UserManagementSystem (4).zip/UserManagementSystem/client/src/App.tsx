import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import Inbox from "@/pages/inbox";
import Tasks from "@/pages/tasks";
import AccountingJournal from "@/pages/accounting/journal";
import AccountingChart from "@/pages/accounting/chart";
import AccountingClosing from "@/pages/accounting/closing";
import AccountingTemplates from "@/pages/accounting/templates";
import AccountingRules from "@/pages/accounting/rules";
import AccountingActivities from "@/pages/accounting/activities";
import AccountingProvisions from "@/pages/accounting/provisions";
import Collection from "@/pages/collection";
import Employees from "@/pages/employees";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import AccessCodes from "@/pages/access-codes";
import ChangeAccessCode from "@/pages/change-access-code";
import Customers from "@/pages/customers";
import Cashier from "@/pages/cashier";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/inbox" component={Inbox} />
      <ProtectedRoute path="/tasks" component={Tasks} />
      <ProtectedRoute path="/accounting/journal" component={AccountingJournal} />
      <ProtectedRoute path="/accounting/chart" component={AccountingChart} />
      <ProtectedRoute path="/accounting/closing" component={AccountingClosing} />
      <ProtectedRoute path="/accounting/templates" component={AccountingTemplates} />
      <ProtectedRoute path="/accounting/rules" component={AccountingRules} />
      <ProtectedRoute path="/accounting/activities" component={AccountingActivities} />
      <ProtectedRoute path="/accounting/provisions" component={AccountingProvisions} />
      <ProtectedRoute path="/collection" component={Collection} />
      <ProtectedRoute path="/employees" component={Employees} />
      <ProtectedRoute path="/access-codes" component={AccessCodes} />
      <ProtectedRoute path="/change-access-code" component={ChangeAccessCode} />
      <ProtectedRoute path="/customers" component={Customers} />
      <ProtectedRoute path="/cashier" component={Cashier} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;