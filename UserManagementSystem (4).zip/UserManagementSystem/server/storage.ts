import { type User, type Task, type AccountingEntry, type ChartOfAccount, type Notification, type CollectionSheet, type InsertUser, type InsertTask, type InsertAccountingEntry, type InsertChartOfAccount, type InsertNotification, type InsertCollectionSheet, type Transaction, type InsertTransaction, type AccountingTemplate, type InsertAccountingTemplate, type AccountingRule, type InsertAccountingRule, type FinancialActivity, type InsertFinancialActivity } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  updateUserAccessCode(userId: number, newAccessCode: string): Promise<User>;

  // Tasks
  createTask(task: InsertTask): Promise<Task>;
  getTasks(): Promise<Task[]>;
  getTasksByUser(userId: number): Promise<Task[]>;
  updateTaskStatus(taskId: number, status: string): Promise<Task>;

  // Notifications
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotifications(userId: number): Promise<Notification[]>;
  markNotificationAsRead(notificationId: number): Promise<void>;

  // Accounting Entries
  createAccountingEntry(entry: InsertAccountingEntry): Promise<AccountingEntry>;
  getAccountingEntries(): Promise<AccountingEntry[]>;
  getAccountingEntriesByType(type: string): Promise<AccountingEntry[]>;

  // Chart of Accounts
  createChartOfAccount(account: InsertChartOfAccount): Promise<ChartOfAccount>;
  getChartOfAccounts(): Promise<ChartOfAccount[]>;
  updateAccountBalance(accountId: number, balance: string): Promise<ChartOfAccount>;

  // Collection Sheets
  createCollectionSheet(sheet: InsertCollectionSheet): Promise<CollectionSheet>;
  getCollectionSheets(): Promise<CollectionSheet[]>;
  getCollectionSheetsByUser(userId: number): Promise<CollectionSheet[]>;

  // Accounting Templates
  createAccountingTemplate(template: InsertAccountingTemplate): Promise<AccountingTemplate>;
  getAccountingTemplates(): Promise<AccountingTemplate[]>;

  // Accounting Rules
  createAccountingRule(rule: InsertAccountingRule): Promise<AccountingRule>;
  getAccountingRules(): Promise<AccountingRule[]>;

  // Financial Activities
  createFinancialActivity(activity: InsertFinancialActivity): Promise<FinancialActivity>;
  getFinancialActivities(): Promise<FinancialActivity[]>;

  // Transactions
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactions(): Promise<Transaction[]>;
  getTransactionsByUser(userId: number): Promise<Transaction[]>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private notifications: Map<number, Notification>;
  private accountingEntries: Map<number, AccountingEntry>;
  private chartOfAccounts: Map<number, ChartOfAccount>;
  private collectionSheets: Map<number, CollectionSheet>;
  private transactions: Map<number, Transaction>;
  private accountingTemplates: Map<number, AccountingTemplate>;
  private accountingRules: Map<number, AccountingRule>;
  private financialActivities: Map<number, FinancialActivity>;

  private currentUserId: number;
  private currentTaskId: number;
  private currentNotificationId: number;
  private currentEntryId: number;
  private currentAccountId: number;
  private currentSheetId: number;
  private currentTransactionId: number;
  private currentTemplateId: number;
  private currentRuleId: number;
  private currentActivityId: number;

  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.notifications = new Map();
    this.accountingEntries = new Map();
    this.chartOfAccounts = new Map();
    this.collectionSheets = new Map();
    this.transactions = new Map();
    this.accountingTemplates = new Map();
    this.accountingRules = new Map();
    this.financialActivities = new Map();

    this.currentUserId = 1;
    this.currentTaskId = 1;
    this.currentNotificationId = 1;
    this.currentEntryId = 1;
    this.currentAccountId = 1;
    this.currentSheetId = 1;
    this.currentTransactionId = 1;
    this.currentTemplateId = 1;
    this.currentRuleId = 1;
    this.currentActivityId = 1;

    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      isActive: true,
      permissions: insertUser.permissions || '[]'
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserAccessCode(userId: number, newAccessCode: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");

    const updatedUser = {
      ...user,
      username: newAccessCode,
      accessCode: newAccessCode
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Task methods
  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const task: Task = { 
      ...insertTask, 
      id,
      createdAt: new Date()
    };
    this.tasks.set(id, task);
    return task;
  }

  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getTasksByUser(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.assignedTo === userId
    );
  }

  async updateTaskStatus(taskId: number, status: string): Promise<Task> {
    const task = this.tasks.get(taskId);
    if (!task) throw new Error("Task not found");
    const updatedTask = { ...task, status };
    this.tasks.set(taskId, updatedTask);
    return updatedTask;
  }

  // Notification methods
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const notification: Notification = { 
      ...insertNotification, 
      id,
      createdAt: new Date(),
      isRead: false
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async getNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.userId === userId
    );
  }

  async markNotificationAsRead(notificationId: number): Promise<void> {
    const notification = this.notifications.get(notificationId);
    if (!notification) throw new Error("Notification not found");
    this.notifications.set(notificationId, { ...notification, isRead: true });
  }

  // Accounting Entry methods
  async createAccountingEntry(insertEntry: InsertAccountingEntry): Promise<AccountingEntry> {
    const id = this.currentEntryId++;
    const entry: AccountingEntry = {
      ...insertEntry,
      id,
      debit: insertEntry.debit || "0",
      credit: insertEntry.credit || "0",
      tags: insertEntry.tags || null,
      metadata: insertEntry.metadata || null
    };
    this.accountingEntries.set(id, entry);
    return entry;
  }

  async getAccountingEntries(): Promise<AccountingEntry[]> {
    return Array.from(this.accountingEntries.values());
  }

  async getAccountingEntriesByType(type: string): Promise<AccountingEntry[]> {
    return Array.from(this.accountingEntries.values()).filter(
      (entry) => entry.type === type
    );
  }

  // Chart of Account methods
  async createChartOfAccount(insertAccount: InsertChartOfAccount): Promise<ChartOfAccount> {
    const id = this.currentAccountId++;
    const account: ChartOfAccount = {
      ...insertAccount,
      id,
      balance: "0",
      isActive: true,
      openingBalance: insertAccount.openingBalance || "0"
    };
    this.chartOfAccounts.set(id, account);
    return account;
  }

  async getChartOfAccounts(): Promise<ChartOfAccount[]> {
    return Array.from(this.chartOfAccounts.values());
  }

  async updateAccountBalance(accountId: number, balance: string): Promise<ChartOfAccount> {
    const account = this.chartOfAccounts.get(accountId);
    if (!account) throw new Error("Account not found");
    const updatedAccount = { ...account, balance };
    this.chartOfAccounts.set(accountId, updatedAccount);
    return updatedAccount;
  }

  // Collection Sheet methods
  async createCollectionSheet(insertSheet: InsertCollectionSheet): Promise<CollectionSheet> {
    const id = this.currentSheetId++;
    const sheet: CollectionSheet = {
      ...insertSheet,
      id,
      totalAmount: insertSheet.totalAmount || "0",
      notes: insertSheet.notes || null
    };
    this.collectionSheets.set(id, sheet);
    return sheet;
  }

  async getCollectionSheets(): Promise<CollectionSheet[]> {
    return Array.from(this.collectionSheets.values());
  }

  async getCollectionSheetsByUser(userId: number): Promise<CollectionSheet[]> {
    return Array.from(this.collectionSheets.values()).filter(
      (sheet) => sheet.collectedBy === userId
    );
  }

  // Accounting Templates methods
  async createAccountingTemplate(insertTemplate: InsertAccountingTemplate): Promise<AccountingTemplate> {
    const id = this.currentTemplateId++;
    const template: AccountingTemplate = {
      ...insertTemplate,
      id,
      createdAt: new Date(),
    };
    this.accountingTemplates.set(id, template);
    return template;
  }

  async getAccountingTemplates(): Promise<AccountingTemplate[]> {
    return Array.from(this.accountingTemplates.values());
  }

  // Accounting Rules methods
  async createAccountingRule(insertRule: InsertAccountingRule): Promise<AccountingRule> {
    const id = this.currentRuleId++;
    const rule: AccountingRule = {
      ...insertRule,
      id,
      isActive: true,
    };
    this.accountingRules.set(id, rule);
    return rule;
  }

  async getAccountingRules(): Promise<AccountingRule[]> {
    return Array.from(this.accountingRules.values());
  }

  // Financial Activities methods
  async createFinancialActivity(insertActivity: InsertFinancialActivity): Promise<FinancialActivity> {
    const id = this.currentActivityId++;
    const activity: FinancialActivity = {
      ...insertActivity,
      id,
      isActive: true,
    };
    this.financialActivities.set(id, activity);
    return activity;
  }

  async getFinancialActivities(): Promise<FinancialActivity[]> {
    return Array.from(this.financialActivities.values());
  }

  // Transaction methods
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const transaction: Transaction = { ...insertTransaction, id };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values());
  }

  async getTransactionsByUser(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId
    );
  }
}

export const storage = new MemStorage();