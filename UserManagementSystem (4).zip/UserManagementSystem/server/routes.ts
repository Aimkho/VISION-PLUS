import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  insertTaskSchema,
  insertAccountingEntrySchema,
  insertChartOfAccountSchema,
  insertNotificationSchema,
  insertCollectionSheetSchema,
  insertAccountingRuleSchema,
  insertFinancialActivitySchema,
  insertAccountingTemplateSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Protected routes middleware
  app.use("/api/*", (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    next();
  });

  // Tasks
  app.get("/api/tasks", async (req, res) => {
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.post("/api/tasks", async (req, res) => {
    const result = insertTaskSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const task = await storage.createTask(result.data);
    res.status(201).json(task);
  });

  // Notifications
  app.get("/api/notifications", async (req, res) => {
    const notifications = await storage.getNotifications(req.user.id);
    res.json(notifications);
  });

  // Accounting Templates
  app.get("/api/accounting/templates", async (req, res) => {
    const templates = await storage.getAccountingTemplates();
    res.json(templates);
  });

  app.post("/api/accounting/templates", async (req, res) => {
    const result = insertAccountingTemplateSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const template = await storage.createAccountingTemplate(result.data);
    res.status(201).json(template);
  });

  // Accounting Entries
  app.get("/api/accounting/entries", async (req, res) => {
    const entries = await storage.getAccountingEntries();
    res.json(entries);
  });

  app.post("/api/accounting/entries", async (req, res) => {
    const result = insertAccountingEntrySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const entry = await storage.createAccountingEntry({
      ...result.data,
      userId: req.user.id,
    });
    res.status(201).json(entry);
  });

  // Chart of Accounts
  app.get("/api/accounting/accounts", async (req, res) => {
    const accounts = await storage.getChartOfAccounts();
    res.json(accounts);
  });

  app.post("/api/accounting/accounts", async (req, res) => {
    if (req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    const result = insertChartOfAccountSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const account = await storage.createChartOfAccount(result.data);
    res.status(201).json(account);
  });

  // Accounting Rules
  app.get("/api/accounting/rules", async (req, res) => {
    const rules = await storage.getAccountingRules();
    res.json(rules);
  });

  app.post("/api/accounting/rules", async (req, res) => {
    const result = insertAccountingRuleSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const rule = await storage.createAccountingRule(result.data);
    res.status(201).json(rule);
  });

  // Financial Activities
  app.get("/api/accounting/activities", async (req, res) => {
    const activities = await storage.getFinancialActivities();
    res.json(activities);
  });

  app.post("/api/accounting/activities", async (req, res) => {
    const result = insertFinancialActivitySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const activity = await storage.createFinancialActivity(result.data);
    res.status(201).json(activity);
  });

  // Collection Sheets
  app.get("/api/collection-sheets", async (req, res) => {
    const sheets = await storage.getCollectionSheets();
    res.json(sheets);
  });

  app.post("/api/collection-sheets", async (req, res) => {
    const result = insertCollectionSheetSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }
    const sheet = await storage.createCollectionSheet({
      ...result.data,
      collectedBy: req.user.id,
    });
    res.status(201).json(sheet);
  });

  // Users - Admin only
  app.get("/api/users", async (req, res) => {
    if (req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    const users = await storage.getUsers();
    res.json(users);
  });

  // Change Access Code
  app.post("/api/change-access-code", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    const { currentCode, newCode } = req.body;
    const user = await storage.getUserByUsername(currentCode);

    if (!user || user.id !== req.user.id) {
      return res.status(400).json({ message: "Code d'accès actuel incorrect" });
    }

    // Mettre à jour le code d'accès et le nom d'utilisateur
    await storage.updateUserAccessCode(user.id, newCode);
    res.sendStatus(200);
  });

  const httpServer = createServer(app);
  return httpServer;
}