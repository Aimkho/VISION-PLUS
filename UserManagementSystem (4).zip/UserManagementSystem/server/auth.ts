import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import { generateAccessCode, generatePasswordFromAccessCode } from "./utils";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

async function initializeAdminUser() {
  const adminAccessCode = "ADMIN123";  // Code d'accès de 8 caractères
  const adminPassword = "ADMIN123#XY";

  // Vérifie si l'administrateur existe déjà
  const existingAdmin = await storage.getUserByUsername(adminAccessCode);
  if (!existingAdmin) {
    await storage.createUser({
      username: adminAccessCode,
      password: await hashPassword(adminPassword),
      fullName: "Administrateur Principal",
      role: "admin",
      email: "admin@optique.com",
      accessCode: adminAccessCode,
      isActive: true,
    });
    console.log("Compte administrateur créé avec succès");
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "dev_secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
  };

  // Initialise le compte administrateur
  initializeAdminUser().catch(console.error);

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      const user = await storage.getUserByUsername(username);
      if (!user || !(await comparePasswords(password, user.password))) {
        return done(null, false);
      } else {
        return done(null, user);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    const user = await storage.getUser(id);
    done(null, user);
  });

  app.post("/api/register", async (req, res, next) => {
    if (req.user?.role !== "admin") {
      return res.status(403).send("Seuls les administrateurs peuvent créer des comptes");
    }

    const accessCode = generateAccessCode();
    const initialPassword = generatePasswordFromAccessCode(accessCode);

    const user = await storage.createUser({
      ...req.body,
      username: accessCode,
      password: await hashPassword(initialPassword),
      accessCode,
    });

    res.status(201).json({
      ...user,
      initialPassword, // Inclut le mot de passe initial dans la réponse
    });
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
