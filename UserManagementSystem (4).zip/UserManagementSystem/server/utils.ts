import { randomBytes } from "crypto";
import { format, startOfMonth, endOfMonth } from "date-fns";

export function generateAccessCode(): string {
  // Génère un code d'accès de 8 caractères exactement
  return randomBytes(4).toString('hex').toUpperCase().slice(0, 8);
}

export function generatePasswordFromAccessCode(accessCode: string): string {
  // Génère un mot de passe initial basé sur le code d'accès
  // Le personnel devra le changer à la première connexion
  return `${accessCode}#${randomBytes(2).toString('hex').toUpperCase().slice(0, 2)}`;
}

export function calculatePeriod(date: Date): string {
  // Retourne la période comptable au format YYYY-MM
  return format(date, 'yyyy-MM');
}

export function getPeriodBounds(period: string): { start: Date; end: Date } {
  // Retourne le début et la fin d'une période comptable
  const [year, month] = period.split('-').map(Number);
  const date = new Date(year, month - 1);
  return {
    start: startOfMonth(date),
    end: endOfMonth(date)
  };
}

export function validateAccountingEntry(entry: any): string[] {
  const errors: string[] = [];

  // Vérifie si le débit et le crédit sont égaux
  if (Number(entry.debit) !== Number(entry.credit)) {
    errors.push("Le débit et le crédit doivent être égaux");
  }

  // Vérifie que les montants sont positifs
  if (Number(entry.debit) < 0 || Number(entry.credit) < 0) {
    errors.push("Les montants doivent être positifs");
  }

  // Vérifie la référence
  if (!entry.reference?.trim()) {
    errors.push("La référence est obligatoire");
  }

  return errors;
}

export function generateReference(type: string, period: string): string {
  // Génère une référence unique pour une écriture comptable
  const timestamp = Date.now().toString(36).toUpperCase();
  return `${type.substring(0, 3)}-${period}-${timestamp}`;
}

export function formatAmount(amount: number | string): string {
  // Formate un montant en euros avec 2 décimales
  return Number(amount).toLocaleString('fr-FR', {
    style: 'currency',
    currency: 'EUR'
  });
}